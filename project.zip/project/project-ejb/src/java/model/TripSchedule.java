/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class TripSchedule {
    private static final long serialVersionUID = 2L;
    @Id
    @Column(name = "trip_schedule_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @OneToMany(mappedBy = "schedule", cascade = CascadeType.ALL)
    private ArrayList<Ticket> ticketsSold = new ArrayList<Ticket>();
    
    @Column(unique = true)
    private String tripDate;
    
    private int availableSeats;
    
    private int price;
    
    public TripSchedule() {
    }
    
    public TripSchedule(String date, int availableSeats, int price) {
        this.tripDate = date;
        this.availableSeats = availableSeats;
        this.price = price;
    }
    
    /**
     * New reservations, reduce inventory, and save tickets to the sold tickets array.
     * An order is considered a new reservation (at this point, the ticket is not paid).
     *      * @param t 
     */
    public void newBooking(Ticket t) {
        this.availableSeats--;
        this.ticketsSold.add(t);
    }
    
    /**
     * Cancel the reservation
     * Add the inventory
     * @param t 
     */
    public void removeTicket(Ticket t) {
       
        // this.ticketsSold.remove(t);
        this.availableSeats++;  
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof User)) {
            return false;
        }
        TripSchedule other = (TripSchedule) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Schedule[ id=" + id + " ]";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ArrayList<Ticket> getTicketsSold() {
        return ticketsSold;
    }

    public void setTicketsSold(ArrayList<Ticket> ticketsSold) {
        this.ticketsSold = ticketsSold;
    }

    public String getTripDate() {
        return tripDate;
    }

    public void setTripDate(String tripDate) {
        this.tripDate = tripDate;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }    
}

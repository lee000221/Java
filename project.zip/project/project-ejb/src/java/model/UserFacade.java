/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class UserFacade extends AbstractFacade<User> {

    @PersistenceContext(unitName = "EPDA-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UserFacade() {
        super(User.class);
    }
    
    /**
     * Search by username
     * @param input
     * @return 
     */
    public User searchByUsername(String input){
        User login = null;
        Query q = em.createNamedQuery("User.searchByUsername");
        q.setParameter("x", input);
        List result = q.getResultList();
        if(result.size()>0){
            login = (User)result.get(0);
        }
        return login;
    }

    /**
     * If the user name does not exist, create a new data
     * @param u 
     */
    public void createIfNotExists(User u) {
        Query q = em.createNamedQuery("User.searchByUsername");
        q.setParameter("x", u.getUsername());
        List result = q.getResultList();
        if (result.size() == 0) {
            create(u);
        }
    }

    /**
     * Keyword + user type for finding
     * @param keyword
     * @param userType
     * @return 
     */
    public List<User> search(String keyword, UserType userType) {
        if (keyword.length() > 0) {
            // Keyword + user type for lookup
            Query q = em.createNamedQuery("User.searchByKeywordAndType");
            q.setParameter("x", "%" + keyword + "%");
            q.setParameter("y", userType);
            return q.getResultList();            
        }
        
        // keywords
        Query q = em.createQuery("SELECT a FROM User a WHERE a.type = :y ORDER By a.id DESC", User.class);
        q.setParameter("y", userType);
        return q.getResultList();
    }

    /**
     * id + user type for lookup 
     * @param id
     * @param userType
     * @return 
     */
    public User findByIdAndUserType(long id, UserType userType) {
        User user = this.find(id);
        if (user.getType() == userType) {
            return user;
        }
        
        return null;
    }

    /**
     * Count the number of customers of a certain gender
     * @param gender
     * @return 
     */
    public Long customerGenderCount(String gender) {
        Query q = em.createQuery("SELECT count(a) FROM User a WHERE a.gender =:x AND a.type = :y ", User.class);
        q.setParameter("x", gender);
        q.setParameter("y", UserType.CUSTOMER);
        List<Long> results =  q.getResultList();
        return results.get(0);
    }

}

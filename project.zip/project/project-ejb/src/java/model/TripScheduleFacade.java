/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class TripScheduleFacade extends AbstractFacade<TripSchedule> {
    @PersistenceContext(unitName = "EPDA-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TripScheduleFacade() {
        super(TripSchedule.class);
    }

    /**
     * Since there is no UI to create Trip Schedule,
     * So when you book a trip for a date, 
     * if you don't have a trip schedule for that day, 
     * you automatically create one.
     * @param journeyDate
     * @return 
     */
    public TripSchedule createIfNotExists(String journeyDate) {
        Query q = em.createQuery("SELECT a FROM TripSchedule a WHERE a.tripDate = :y ", TripSchedule.class);
        q.setParameter("y", journeyDate);
        List result = q.getResultList();
        TripSchedule ts;
        if (result.size() == 0) {
            // Create a new one
            ts = new TripSchedule(journeyDate, 50, 10);
            create(ts);
        } else {
            ts = (TripSchedule) result.get(0);
        }
        
        return ts;
    }
}

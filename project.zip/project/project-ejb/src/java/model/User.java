/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 *
 * @author Administrator
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "User.searchByUsername", 
            query = "SELECT a FROM User a WHERE a.username = :x"),
    
    @NamedQuery(name = "User.searchByKeywordAndType", 
            query = "SELECT a FROM User a WHERE (a.username LIKE :x OR "
                    + "a.name LIKE :x OR a.email LIKE :x) "
                    + "AND a.type= :y ORDER BY a.id DESC"),
    
})
public class User {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "user_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    private String name;
    private String gender;
    
    @Column(unique = true)
    private String username;
    private String password;
        
    private String email;
    private double salary;
    
    @Enumerated(EnumType.STRING)
    private UserType type;
    
    public User() {
        
    }
    
    public User(String name, String gender, 
            String username, String password,
            String email, double salary, UserType type) {
        this.name = name;
        this.gender = gender;
        
        this.username = username;
        this.password = password;
        
        this.email = email;
        this.salary = salary;
        
        this.type = type;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof User)) {
            return false;
        }
        User other = (User) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.User[ id=" + id + " ]";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public UserType getType() {
        return type;
    }

    public void setType(UserType type) {
        this.type = type;
    }
   
}

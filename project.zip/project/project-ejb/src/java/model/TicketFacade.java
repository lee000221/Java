/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class TicketFacade extends AbstractFacade<Ticket> {
    @PersistenceContext(unitName = "EPDA-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TicketFacade() {
        super(Ticket.class);
    }

    /**
     * Search by passenger and keyword
     * @param user
     * @param keyword
     * @return 
     */
    public List<Ticket> search(User user, String keyword) {
        if (keyword.length() > 0) {
            // Passenger + Keywords
            Query q = em.createQuery("SELECT a FROM Ticket a WHERE a.journeyDate like :x AND a.passenger = :y ORDER By a.id DESC", Ticket.class);
            q.setParameter("x", "%" + keyword + "%");
            q.setParameter("y", user);
            return q.getResultList();            
        }
        
        // Search by Passenger
        Query q = em.createQuery("SELECT a FROM Ticket a WHERE a.passenger = :y ORDER By a.id DESC", Ticket.class);
        q.setParameter("y", user);
        return q.getResultList();
    }

    /**
     * Create an order (ticket)
     * @param journeyDate
     * @param ts
     * @param user
     * @return
     * @throws Exception 
     */
    public Ticket book(String journeyDate, TripSchedule ts, User user) throws Exception {
        // Check the inventory
        if (ts.getAvailableSeats() == 0) {
            throw new Exception("Booking failed: no available seats.");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // The seat number is +1 for the number of tickets sold
        int seatNumber = ts.getTicketsSold().size() + 1;
        //  Create a new ticket and the status is to be paid
        Ticket t = new Ticket(TicketStatus.TO_BE_PAID, 
            ts, seatNumber, journeyDate, user,
            new Date());
        this.create(t);
        return t;
    }

    /**
     * Find tickets by key words
     * @param keyword
     * @return 
     */
    public List<Ticket> searchAll(String keyword) {
        if (keyword.length() > 0) {
            // Keyword search
            Query q = em.createQuery("SELECT a FROM Ticket a WHERE a.journeyDate like :x OR a.passenger.name LIKE :x "
                    + "OR a.passenger.email LIKE :x OR a.passenger.username LIKE :x"
                    + " ORDER By a.id DESC", Ticket.class);
            q.setParameter("x", "%" + keyword + "%");
            return q.getResultList();            
        }
        
        // Looking for all
        Query q = em.createQuery("SELECT a FROM Ticket a  ORDER By a.id DESC", Ticket.class);
        return q.getResultList();    
    }

    /**
     * Count the sales for each day within the date range
     * @param start
     * @param end
     * @return 
     */
    public Map<String, Long> sumGroupByCreateDateBetween(Date start, Date end) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Map<String, Long>map = new HashMap<>();
        Query q = em.createQuery("SELECT a.createDate, sum(a.schedule.price) FROM Ticket a  "
                + "WHERE a.createDate BETWEEN :x AND :y "
                + "AND a.status = :z  GROUP BY a.createDate", Ticket.class);
        q.setParameter("x", start);
        q.setParameter("y", end);
        // 仅统计已支付状态的订单
        q.setParameter("z", TicketStatus.PAID);
        List results =  q.getResultList();
        // Save it in a map, where the key is the date and the value is the sales volume of the day.
        for (int i = 0; i < results.size(); i++) {
            Object[] row = (Object[]) results.get(i);
            String key = sdf.format((Date) row[0]);
            Long value = (Long) row[1];
            map.put(key, value);
        }
        System.out.println("=== map size: " + map.size());
        return map;
    }

}

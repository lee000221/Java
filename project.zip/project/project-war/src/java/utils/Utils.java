package utils;


import java.io.PrintWriter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class Utils {
    /**
     * Output error message in HTML format
     * @param out
     * @param msg 
     */
    public static void outputErrorMsg(PrintWriter out, String msg) {
        out.println("<div class=\"alert alert-primary\" role=\"alert\">" + msg + "</div>");
    } 
}

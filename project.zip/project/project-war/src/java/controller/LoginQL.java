/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import utils.Utils;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.User;
import model.UserType;
import model.UserFacade;

/**
 * login
 * @author guan.kiat
 */
@WebServlet(name = "LoginQL", urlPatterns = {"/LoginQL"})
public class LoginQL extends HttpServlet {

    @EJB
    private UserFacade userFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // create a default admin user.
        User defaultAdmin = new User();
        defaultAdmin.setName("Administrator");
        defaultAdmin.setUsername("admin");
        defaultAdmin.setPassword("12");
        defaultAdmin.setType(UserType.ADMIN);
        userFacade.createIfNotExists(defaultAdmin);
        
        // To obtain parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        // Lookup in the database by user name 
        User login = userFacade.searchByUsername(username);
        
        try (PrintWriter out = response.getWriter()) {
            if(login==null){
                // If the user does not exist, jump to login.jsp
                request.getRequestDispatcher("login.jsp").include(request, response);
                Utils.outputErrorMsg(out, "Wrong username!");
            } else{
                if(!login.getPassword().equals(password)){
                    // Password Inconsistency
                    request.getRequestDispatcher("login.jsp").include(request, response);
                    Utils.outputErrorMsg(out, "Wrong password!");
                } else{
                    // Verify passed, ready to write session
                    HttpSession s = request.getSession();
                    
                    if (login.getType() == UserType.ADMIN) {
                        // The administrator writes the ADMIN_LOGIN SESSION, 
                        //and jumps to the administrator's home page
                        s.setAttribute("admin_login", login);
                        response.sendRedirect("Admin/Index");
                        return;
                    }
                    
                    if (login.getType() == UserType.STAFF) {
                        // The staff writes the SALES_LOGIN session and jumps to the sales home page
                        s.setAttribute("sales_login", login);
                        response.sendRedirect("Sales/Index");
                        return;
                    }
                    
                    if (login.getType() == UserType.CUSTOMER) {
                        // ditto
                        s.setAttribute("customer_login", login);
                        response.sendRedirect("Customer/Index");
                        return;
                    }
                    
                    // error
                    request.getRequestDispatcher("login.jsp").include(request, response);
                    Utils.outputErrorMsg(out, "unknown usertype!");
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

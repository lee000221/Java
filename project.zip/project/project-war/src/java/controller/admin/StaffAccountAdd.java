/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.User;
import model.UserFacade;
import model.UserType;

/**
 *Add staff
 * @author Administrator
 */
@WebServlet(name = "AdminStaffAccountAdd", urlPatterns = {"/Admin/StaffAccountAdd"})
public class StaffAccountAdd extends HttpServlet {

    @EJB
    private UserFacade userFacade;
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. 
    //Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // Check the session if there is no session and jump back to the login page
        HttpSession s = request.getSession(false);
        User login = (User)s.getAttribute("admin_login");
        if (login == null) {
            response.sendRedirect("../login.jsp");
            return;
        }
        
        // 
        request.getRequestDispatcher("../admin/staff_account_add.jsp").forward(request, response);

    }

    /**Loading the JSP page
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // Check the session if there is no session and jump back to the login page
        HttpSession s = request.getSession(false);
        User login = (User)s.getAttribute("admin_login");
        if (login == null) {
            response.sendRedirect("../login.jsp");
            return;
        }
        
        // Gets the submitted parameters
        String name = request.getParameter("name").trim();
	String gender = request.getParameter("gender").trim();

        String username = request.getParameter("username").trim();
	String password = request.getParameter("password").trim();
        
        String email = request.getParameter("email").trim();
        Double salary = 0.0;
        String error = "";
        try {
            // Change string salary to double
            salary = Double.parseDouble(request.getParameter("salary").trim());
        } catch (Exception e) {
            // Error conversion, jump back to JSP page where staff is added
            error = "Salary must be double.";
            request.setAttribute("error", error);
            request.getRequestDispatcher("../admin/staff_account_add.jsp").forward(request, response);
            return;
        }

        // Create a user
        User u = new User(name, gender, username, password, email, salary, UserType.STAFF);
        String message = "";
        try {
            //  Save it to the database
            userFacade.create(u);
        } catch (Exception e) {
            message = e.getMessage();
        }
        //  Jump to the Staff Account list page
        response.sendRedirect("StaffAccountIndex?message=" + URLEncoder.encode(message, "utf-8"));

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

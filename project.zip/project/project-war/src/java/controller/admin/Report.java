/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.TicketFacade;
import model.User;
import model.UserFacade;

/**
 * report page
 * @author Administrator
 */
@WebServlet(name = "AdminReport", urlPatterns = {"/Admin/Report"})
public class Report extends HttpServlet {

    @EJB
    private UserFacade userFacade;
    
    @EJB
    private TicketFacade ticketFacade;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        //Check the session if there is no session and jump back to the login page
        HttpSession s = request.getSession(false);
        User login = (User)s.getAttribute("admin_login");
        if (login == null) {
            response.sendRedirect("../login.jsp");
            return;
        }
        // To obtain parameters
        String startDate = request.getParameter("start_date");
        String endDate = request.getParameter("end_date");
        if (startDate == null) {
            startDate = "";
        }
        if (endDate == null) {
            endDate = "";
        }
        startDate = startDate.trim();
        endDate = endDate.trim();
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date sd;
        Date ed;
        try {
            // Convert the start and end date parameters from String to date type
            sd = sdf.parse(startDate);
            ed = sdf.parse(endDate);
        } catch (ParseException ex) {
            // Unable to convert for various reasons, use the default value
            ed = new Date();
            sd = new Date(ed.getTime() - 86400 * 6 * 1000);
        }
        
        System.out.println("=== sd: " + sdf.format(sd));
        System.out.println("=== ed: " + sdf.format(ed));
        
        // An array to hold dates
        ArrayList<String> days = new ArrayList<String>();
        // An array to hold daily sales
        ArrayList<String> values = new ArrayList<String>();
        Date d = sd;
        // Query daily sales from the database
        Map<String, Long> map = ticketFacade.sumGroupByCreateDateBetween(sd, ed);
        // Iterate the start date to the end date
        while (d.getTime() <= ed.getTime()) {
            String key = sdf.format(d);
            System.out.println("=== key: " + key + ", " + map.containsKey(key));
            // The sales volume is retrieved from the Map by date
            // And save them to the end of each array
            if (map.containsKey(key)) {
                days.add("'" + key + "'");
                values.add("" + map.get(key));
            }
            d = new Date(d.getTime() + 86400 * 1000);
        }
        
        // Arrays turn into strings
        String lineLabels = String.join(", ", days);
        String lineValues = String.join(", ", values);
        
        // Query the number of customers for male and female from the database
        long maleCount = userFacade.customerGenderCount("male");
        long femaleCount = userFacade.customerGenderCount("female");
        
        // The value to the JSP
        request.setAttribute("maleCount", maleCount);
        request.setAttribute("femaleCount", femaleCount);
        request.setAttribute("startDateStr", sdf.format(sd));
        request.setAttribute("endDateStr", sdf.format(ed));
        request.setAttribute("lineLabels", lineLabels);
        request.setAttribute("lineValues", lineValues);
        // Loading the JSP page
        request.getRequestDispatcher("../admin/report.jsp").include(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

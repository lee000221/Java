/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.sales;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.User;
import model.UserFacade;
import model.UserType;

/**
 * edit customer
 * @author Administrator
 */
@WebServlet(name = "SalesCustomerAccountEdit", urlPatterns = {"/Sales/CustomerAccountEdit"})
public class CustomerAccountEdit extends HttpServlet {
    @EJB
    private UserFacade userFacade;

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // 检查 session 无session的话跳回登录页
        HttpSession s = request.getSession(false);
        User login = (User)s.getAttribute("sales_login");
        if (login == null) {
            response.sendRedirect("../login.jsp");
            return;
        }
        
        // 获取id参数
        long id = -1; 
        try {
            id = Long.parseLong(request.getParameter("id").trim());
        } catch (Exception e) {
            id = -1;
        }
        if (id <= 0) {
            String message = "invalid id";
            response.sendRedirect("CustomerAccountIndex?message=" + URLEncoder.encode(message, "utf-8"));
            return;
        }
        
        // 在数据库中根据id参数和用户类型进行查找 
        User user = userFacade.findByIdAndUserType(id, UserType.CUSTOMER);
        // 传值给jsp并加载jsp页面
        request.setAttribute("user", user);

        request.getRequestDispatcher("../sales/customer_account_edit.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // 检查 session 无session的话跳回登录页
        HttpSession s = request.getSession(false);
        User login = (User)s.getAttribute("sales_login");
        if (login == null) {
            response.sendRedirect("../login.jsp");
            return;
        }
        // 获取提交的参数
        String name = request.getParameter("name").trim();
	String gender = request.getParameter("gender").trim();

        String username = request.getParameter("username").trim();
	String password = request.getParameter("password").trim();
        
        String email = request.getParameter("email").trim();

        
        long id = Long.parseLong(request.getParameter("id").trim());
        // 根据id参数和用户类型在数据库中查找 
        User user = userFacade.findByIdAndUserType(id, UserType.CUSTOMER);
        // 更新各字段
        user.setName(name);
        user.setGender(gender);
        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        // user.setSalary(salary);
        String message = "";
        try {
            // 更新回数据库
            userFacade.edit(user);
        } catch (Exception e) {
            message = e.getMessage();
        }
        response.sendRedirect("CustomerAccountIndex?message=" + URLEncoder.encode(message, "utf-8"));
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.sales;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.User;
import model.UserFacade;
import model.UserType;

/**
 * The new customer
 * @author Administrator
 */
@WebServlet(name = "SalesCustomerAccountAdd", urlPatterns = {"/Sales/CustomerAccountAdd"})
public class CustomerAccountAdd extends HttpServlet {

    @EJB
    private UserFacade userFacade;

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // 检查 session 无session的话跳回登录页
        HttpSession s = request.getSession(false);
        User login = (User)s.getAttribute("sales_login");
        if (login == null) {
            response.sendRedirect("../login.jsp");
            return;
        }
        
        // 加载jsp
        request.getRequestDispatcher("../sales/customer_account_add.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // 检查 session 无session的话跳回登录页
        HttpSession s = request.getSession(false);
        User login = (User)s.getAttribute("sales_login");
        if (login == null) {
            response.sendRedirect("../login.jsp");
            return;
        }
        
        // 获取参数
        String name = request.getParameter("name").trim();
	String gender = request.getParameter("gender").trim();

        String username = request.getParameter("username").trim();
	String password = request.getParameter("password").trim();
        
        String email = request.getParameter("email").trim();

        // 创建用户
        User u = new User(name, gender, username, password, email, 0.0, UserType.CUSTOMER);
        String message = "";
        try {
            // 保存到数据库
            userFacade.create(u);
        } catch (Exception e) {
            message = e.getMessage();
        }
        // 跳回customer account列表页
        response.sendRedirect("CustomerAccountIndex?message=" + URLEncoder.encode(message, "utf-8"));

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
